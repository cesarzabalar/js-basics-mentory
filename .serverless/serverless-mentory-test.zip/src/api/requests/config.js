const requestConfig = {
    url: '',
    hostname: '',
    path: '',
    method: 'GET',
    port: 443,
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': 0
    },
    body: null
}

module.exports = Object.seal(requestConfig)